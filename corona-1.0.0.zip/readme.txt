=== Corona ===

Contributors: MehediH
Tags: windows 10, mdl2, mdl, windows

Requires at least: 4.0
Tested up to: 4.5.3
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Corona is a simple WordPress theme, inspired by Windows 10's MDL2 design language.