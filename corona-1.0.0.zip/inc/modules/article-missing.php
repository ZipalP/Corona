<article class="not-found">  
    <h3>No posts found</h3>
</article>